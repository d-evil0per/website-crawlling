<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html>
<head>
	<script src="./assets/js/crawl.js" ></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
	</head>
	<body style="text-align:justify;background-color:#000000;color:#00FF00">
<center><h1>Web Crawling</h1></center>
	<h3>Enter any url followed by space:</h3>
<input type="hidden" id="baseurl" value="<?=base_url()?>">
 <input type="text" onkeyup="crawl(this)" style="border:1px solid #00FF00; background-color:transparent;color:#ff0000;margin:10px" placeholder="url">
 <center><p id="processstr" style="display:none"> <span id="process">0</span>%</p></center>
<table style="display:none" id="tab" >
	<tr>

		<td style="border:1px solid #00FF00">
<p>preview <br>
<object data="#" id="preview"
        width="500" height="500">
  <p> <a href="" id="previewtxt">
    Fallback link for browsers that don't support iframes
  </a> </p>
</object>
</p>
</td>
<td style="border:1px solid #00FF00">
<p>Source <br>
<pre id="source"  style='text-align:left;width:500px;height:500px;overflow:scroll;'>
	
        

</pre>

</p>
</td>
</tr>
<tr>
	<td style="border:1px solid #00FF00">
	 <pre id="output" style="text-align:left; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; width:500px">
	 	
 </pre>
</td>
<td style="border:1px solid #00FF00">
		 <pre id="output1" style="text-align:left; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;  width: 500px">
	
 </pre>
	</td>
	</tr>
</table>


 

	</body>
	</html>